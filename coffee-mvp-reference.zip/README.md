# Coffee journal — design reference

Status: approved MVP flow; Clean Studio selected; final app name pending.
Reference date: 2026-10-05.

## Files

- `prototype.html`: standalone, interactive Clean Studio reference. Open directly in a browser. No build, installation, account, or network is required.
- `MVP_SPEC.md`: the agreed product behavior and design rules. This is the implementation target, not an orchestrator prompt.
- `FLOW_MAP.md`: screen inventory, navigation, and walkthroughs.
- `capture-screenshots.mjs`: optional screenshot capture for agents with Playwright and a browser already available.
- `LUCIDE_LICENSE.txt`: license for the bundled icon library.

## Using this with Hermes

Place this folder inside the project's `design-reference/` directory.

The orchestrator and coder can read the Markdown files and inspect the readable application script inside `prototype.html`. The visual reviewer can open the HTML in its browser tooling and capture the actual screens. An agent needs browser/screenshot tools to assess appearance; text access alone is insufficient for visual verification.

Open `prototype.html`, then try the walkthroughs in `FLOW_MAP.md`.

If local file navigation is unavailable in a browser tool, serve this folder locally:

```bash
python3 -m http.server 8080 --bind 127.0.0.1
```

The preview is then at `http://127.0.0.1:8080/prototype.html` on that machine. A browser on another computer requires an SSH tunnel or a separately configured private connection.

For screenshot capture, when Playwright and its Chromium executable are already installed:

```bash
node capture-screenshots.mjs
```

This creates a `screenshots/` folder. The capture script does not install dependencies, change the server, or open network ports. It has not been browser-tested in the export environment because a Chromium executable was unavailable there.

## Prototype limits

This is a design reference, not a production app. Bag scanning, enrichment and community statistics use clearly labeled examples. Demo edits live in memory and reset on reload. The actual implementation must persist real coffees and brews and implement the extraction, enrichment and sharing described in `MVP_SPEC.md`.

The prototype's placeholder identity is “Coffee Journal.” It intentionally does not assume the next product name.

## Verification of this reference

The application script was parsed and its interactions exercised with a DOM test harness. Checks covered the three quick attributes, shared values across rating modes, overall score preservation, editing without duplicate brews, recipe copying, and pour totals. Browser screenshot verification remains for an environment with an installed browser.
